 <?php ?>
<!DOCTYPE html>
<html>
<head>
	<title>Windermere&#39; Commercial :: <?php echo $pageTitle; ?></title>
 <?php echo get_stylesheet_style.css(); ?> 
	<meta name="keywords" content="commercial real estate, listings, commercial properties, for sale, for lease, spokane, coeur d'alene, eastern washington, inland northwest, north idaho, sds realty, seattle, tacoma, portland, bend, washington state, oregon, idaho, northwest, puget sound" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	<div class="main"> 
 