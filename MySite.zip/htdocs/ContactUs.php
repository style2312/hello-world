<?php ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Windermere Commercial </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="HandheldFriendly" content="true" />
	<meta name="MobileOptimized" content="width" />
	<meta name="description" content="Windermere Commercial Real Estate" />
	<meta name="keywords" content="commercial real estate, listings, commercial properties, for sale, for lease, spokane, coeur d'alene, eastern washington, inland northwest, north idaho, sds realty, seattle, tacoma, portland, bend, washington state, oregon, idaho, northwest, puget sound" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	
	<div id="ContactUs">
		<div id="header">
			<div id="header-top"></div>
			<div id="header-middle" style="height:300px;">   
				<div id="header-left" style="height:300px;"> 
					<img id="logo" src="img/logo.jpg"/>
					<div id="contact">
						<h2><span>(509)</span> 747-1051</h2>
						<h3>2829 South Grand Blvd, Suite 101<br />
						Spokane, WA 99223</h3>
					</div>  
				</div>  
				<div id="ShortRightPanel" >
					<div id="TopNav" style="margin:0 auto; position:relative; background-color:#003e7b;">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="agents.php">Our Agents</a></li>
							<li><a href="customSearch.php"  id="CustomSearch">Custom Search</a></li>
							<li><a href="aboutus.php">Our Company</a></li>
							<li><a href="contactus.php">Contact Us</a></li>
						</ul>
					</div>
					<!--<table id="top-nav">
						<tr>
							<td><a href="Index.php"><div class="button">Home</div></a></td>
							<td><a href="agents.php"><div class="button">Our Agents</div></a></td>
							<td><a href="customSearch.php"><div class="button" id="search">Custom Search</div></a></td>
							<td><a href="aboutus.php"><div class="button" id="company">Our Company</div></a></td>
							<td><a href="contactus.php"><div class="button">Contact Us</div></a></td>
						</tr>
					</table>-->
					<div id="divOuterStyle" style="position:relative; width:952px; height:350px; line-height:0; overflow: hidden;">
						<div id="idPanel1" style="position: absolute; z-index: 5; opacity: 1; display: none;">
							<img src="img/retail.cb.jpg" id="idTitleSlideimg1" width="951" height="536" style="margin-top:-75px;  z-index:95;">
						</div>
						<div id="idPanel2" style="position: absolute; z-index: 5; opacity: 1; display: none;">
							<img src="img/business.cb.jpg" id="idTitleSlideimg2" style="border:0; width:952px; height:536px; margin-top:-75px; z-index:86;">
						</div>
						<div id="idPanel3" style="position: absolute; z-index: 10;">
							<img src="img/hospitality.cb.jpg" id="idTitleSlideimg3" style="border:0; width:952px; height:536px; z-index:76;  margin-top:-70px;">
						</div>
					</div>
				</div>  
				<div id="BottomBorder"></div>
			</div> <!-- /header -->
			
			<div id="LeftPanel" style="float:left;padding-right:30px;">

			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2688.8827971611126!2d-117.40351548436365!3d47.62840947918611!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x549e228e0c072677%3A0x86024a6ec0023b39!2s2829+S+Grand+Blvd%2C+Spokane%2C+WA+99203!5e0!3m2!1sen!2sus!4v1489310127698" width="310" height="300" frameborder="0" style="border:0;" allowfullscreen></iframe>
			<h3>Local Office Click for Directions</h3>

			 
			</div>
			<div id="right-panel">
				
				<div id="contact">
	 <table style="width:710px;">
		 <tr>
			 <td width="365" >
				<h3>Windermere Manito Commercial</h3>
				<p>509-747-1051<br/>
					commercial@windermere.com<br/>
					2829 S. Grand Blvd. Suite 101<br/>
					Spokane, WA 99203
				</p>	
			</td>
			 <td width="345">	
				<h3>Windermere Corporate Office</h3>
				<p>	5424 Sand Point Way NE	<br/>
					Seattle, WA 98105<br/>
					206-527-3801	<br/>
					wsc@windermere.com
				</p>
			</td>
			 </tr>
		 <tr>
			 <td>		
				<h3>Mountain West (Eastern Washington,<br/> Idaho, Montana, Wyoming)</h3>
				<p>Windermere Services Mountain West<br/>
				25 West Cataldo, Suite A<br/>
				Spokane, WA 99201<br/>
				509-468-2923<br/>
				wsmw@windermere.com</td>
			<td></td>
		 </tr>
		 </table>
		
				</div>  	
			</div>
		</div>
		
	</div>
  