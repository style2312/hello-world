<?php ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Windermere Commercial </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="HandheldFriendly" content="true" />
	<meta name="MobileOptimized" content="width" />
	<meta name="description" content="Windermere Commercial Real Estate" />
	<meta name="keywords" content="commercial real estate, listings, commercial properties, for sale, for lease, spokane, coeur d'alene, eastern washington, inland northwest, north idaho, sds realty, seattle, tacoma, portland, bend, washington state, oregon, idaho, northwest, puget sound" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	
	<div id="Index">
		<div id="header">
			<div id="header-top"></div>
			<div id="header-middle" style="height:300px;">   
				<div id="header-left" style="height:300px;"> 
					<img id="logo" src="img/logo.jpg"/>
					<div id="contact">
						<h2><span>(509)</span> 747-1051</h2>
						<h3>2829 South Grand Blvd, Suite 101<br />
						Spokane, WA 99223</h3>
					</div>  
				</div>  
				<div id="ShortRightPanel">
					<div id="TopNav" style="margin:0 auto; position:relative; background-color:#003e7b;">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="agents.php">Our Agents</a></li>
							<li><a href="customSearch.php"  id="CustomSearch">Custom Search</a></li>
							<li><a href="aboutus.php">Our Company</a></li>
							<li><a href="contactus.php">Contact Us</a></li>
						</ul>
					</div>
					<!--<table id="top-nav">
						<tr>
							<td><a href="Index.php"><div class="button">Home</div></a></td>
							<td><a href="agents.php"><div class="button">Our Agents</div></a></td>
							<td><a href="customSearch.php"><div class="button" id="search">Custom Search</div></a></td>
							<td><a href="aboutus.php"><div class="button" id="company">Our Company</div></a></td>
							<td><a href="contactus.php"><div class="button">Contact Us</div></a></td>
						</tr>
					</table>-->
					<div id="divOuterStyle" style="position:relative; width:952px; height:350px; line-height:0; overflow: hidden;">
						<div id="idPanel1" style="position: absolute; z-index: 5; opacity: 1; display: none;">
							<img src="img/retail.cb.jpg" id="idTitleSlideimg1" width="951" height="536" style="margin-top:-75px;  z-index:95;">
						</div>
						<div id="idPanel2" style="position: absolute; z-index: 5; opacity: 1; display: none;">
							<img src="img/business.cb.jpg" id="idTitleSlideimg2" style="border:0; width:952px; height:536px; margin-top:-75px; z-index:86;">
						</div>
						<div id="idPanel3" style="position: absolute; z-index: 10;">
							<img src="img/hospitality.cb.jpg" id="idTitleSlideimg3" style="border:0; width:952px; height:536px; z-index:76;  margin-top:-70px;">
						</div>
					</div>
				</div>  
				<div id="BottomBorder" style="border-bottom:4px solid #003e7b;"></div>
			</div> <!-- /header -->
			
			<div id="LeftPanel" style="float:left; border-bottom:6px solid #003e7b;">
				 
			</div>
			<div id="right-panel">
				 
			</div>
		</div>
	</div>
 

